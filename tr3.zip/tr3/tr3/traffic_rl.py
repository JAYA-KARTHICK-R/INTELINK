import os
import traci
import gym
import numpy as np
.

# Set the SUMO environment variable
sumo_binary = "sumo-gui"  # or "sumo" for command-line interface
sumo_config = "D:/221501507/tr3/tr3/tr3.sumocfg"  # Update to your SUMO config path

# Define the environment class
class SumoEnv(gym.Env):
    def __init__(self):
        super(SumoEnv, self).__init__()
        traci.start([sumo_binary, "-c", sumo_config])
        
        self.action_space = gym.spaces.Discrete(4)  # Define action space (e.g., 4 traffic light states)
        self.observation_space = gym.spaces.Box(low=0, high=1, shape=(4,), dtype=np.float32)  # Example observation space
    
    def step(self, action):
        traci.simulationStep()  # Advance simulation by one step
        
        # Example: Modify traffic light based on action
        if action == 0:
            traci.trafficlight.setPhase("0", 0)  # Phase 0
        elif action == 1:
            traci.trafficlight.setPhase("0", 2)  # Phase 2
        elif action == 2:
            traci.trafficlight.setPhase("0", 4)  # Phase 4
        elif action == 3:
            traci.trafficlight.setPhase("0", 6)  # Phase 6
        
        # Obtain the new state and reward
        state = self._get_state()
        reward = self._get_reward()
        
        done = traci.simulation.getMinExpectedNumber() == 0  # Check if simulation ended
        
        return state, reward, done, {}
    
    def _get_state(self):
        # Define how to get the state (e.g., vehicle density, waiting time, etc.)
        state = np.array([traci.edge.getLastStepOccupancy(edge_id) for edge_id in ["edge1", "edge2", "edge3", "edge4"]])
        return state
    
    def _get_reward(self):
        # Define the reward function (e.g., negative waiting time, negative emission, etc.)
        reward = -sum([traci.edge.getWaitingTime(edge_id) for edge_id in ["edge1", "edge2", "edge3", "edge4"]])
        return reward
    
    def reset(self):
        traci.load([sumo_binary, "-c", sumo_config])
        return self._get_state()
    
    def render(self, mode='human'):
        pass
    
    def close(self):
        traci.close()

# Instantiate the environment
env = SumoEnv()

# Define the RL model (DQN in this case)
model = DQN('MlpPolicy', env, verbose=1)

# Train the model
model.learn(total_timesteps=10000)

# Save the model
model.save("dqn_sumo_traffic")

# Close the environment
env.close()
