import traci
import numpy as np
import tensorflow as tf
from collections import deque
import random

# Parameters
STATE_SIZE = 8  # Adjust based on number of lanes and signals
ACTION_SIZE = 4  # Number of possible actions for the RL agent (one per signal)
EPISODES = 1000
SAVE_MODEL = "traffic_light_model.h5"

# Load SUMO and initialize traffic lights
def start_sumo(sumoCmd):
    traci.start(sumoCmd)
    return ["cluster_10901554492_10901554493_10901554494_10901563826","cluster_10901554451_10901554489_10901554491_11939438383","2169039261","cluster_10292799694_252299774_311366010_618647392"]  # Signal IDs

def get_state(signals):
    state = []
    for signal in signals:
        lanes = traci.trafficlight.getControlledLanes(signal)
        for lane in lanes:
            state.append(traci.edge.getLastStepVehicleNumber(lane))
    return np.array(state)

def train_dqn(sumoCmd):
    signals = start_sumo(sumoCmd)
    model = build_model()
    replay_buffer = deque(maxlen=2000)
    for episode in range(EPISODES):
        traci.simulationStep()  # Advance the simulation
        state = get_state(signals)
        state = np.reshape(state, [1, STATE_SIZE])
        action = np.argmax(model.predict(state))  # Take action based on the model
        execute_action(action, signals)  # Apply the chosen action
        next_state = get_state(signals)
        next_state = np.reshape(next_state, [1, STATE_SIZE])
        reward = get_reward(state, next_state)
        replay_buffer.append((state, action, reward, next_state))
        if len(replay_buffer) > 32:
            train_from_replay(model, replay_buffer)
        if episode % 100 == 0:  # Save the model periodically
            model.save(SAVE_MODEL)
        if traci.simulation.getMinExpectedNumber() <= 0:  # Stopping condition
            break
    traci.close()

def build_model():
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(24, input_dim=STATE_SIZE, activation='relu'),
        tf.keras.layers.Dense(24, activation='relu'),
        tf.keras.layers.Dense(ACTION_SIZE, activation='linear')
    ])
    model.compile(loss='mse', optimizer=tf.keras.optimizers.Adam(learning_rate=0.001))
    return model


def execute_action(action, signals):
    for signal in signals:
        traci.trafficlight.setPhase(signal, action)

def get_reward(state, next_state):
    # Custom reward function based on traffic flow improvement
    return np.sum(next_state) - np.sum(state)

def train_from_replay(model, replay_buffer):
    minibatch = random.sample(replay_buffer, 32)
    for state, action, reward, next_state in minibatch:
        target = reward + 0.95 * np.max(model.predict(next_state))
        target_f = model.predict(state)
        target_f[0][action] = target
        model.fit(state, target_f, epochs=1, verbose=0)

sumoCmd = ["sumo-gui", "-c", "t2.sumocfg"]  # Replace with your SUMO config
train_dqn(sumoCmd)
