import os
import sys
import traci
import numpy as np
import random
from collections import deque
import tensorflow as tf
from tensorflow import keras
layers = keras.layers

# Constants
GAMMA = 0.99
LEARNING_RATE = 0.001
MEMORY_SIZE = 2000
BATCH_SIZE = 32
EPSILON = 1.0
EPSILON_DECAY = 0.995
EPSILON_MIN = 0.01
EPISODES = 2
SAVE_MODEL = "traffic1_light_model.keras"
MIN_GREEN_DURATION = 10  # Minimum time for a green light phase

# Traffic light IDs for four intersections
traffic_light_ids = [
    "cluster_10901554492_10901554493_10901554494_10901563826",
    "cluster_10901554451_10901554489_10901554491_11939438383",
    "2169039261",
    "cluster_10292799694_252299774_311366010_618647392"
]  # Replace with your actual traffic light IDs

# Automatically determine STATE_SIZE
NUM_FEATURES_PER_INTERSECTION = 6  # 1 for current phase + 5 lanes with vehicle counts
STATE_SIZE = NUM_FEATURES_PER_INTERSECTION * len(traffic_light_ids)
ACTION_SIZE = 4 ** len(traffic_light_ids)  # Example: 4 phases per light ^ 4 intersections

# DQN Model
def build_model():
    model = tf.keras.Sequential()
    model.add(layers.Dense(64, input_dim=STATE_SIZE, activation='relu'))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(ACTION_SIZE, activation='linear'))
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
                  loss='mse')
    return model

# Replay Memory
memory = deque(maxlen=MEMORY_SIZE)

# Epsilon-greedy policy
def act(state, epsilon, model):
    if np.random.rand() <= epsilon:
        return random.randrange(ACTION_SIZE)
    q_values = model.predict(state)
    return np.argmax(q_values[0])

# Replay experience
def replay(model, target_model):
    if len(memory) < BATCH_SIZE:
        return
    minibatch = random.sample(memory, BATCH_SIZE)
    for state, action, reward, next_state, done in minibatch:
        target = reward
        if not done:
            target = reward + GAMMA * np.amax(target_model.predict(next_state)[0])
        target_f = model.predict(state)
        target_f[0][action] = target
        model.fit(state, target_f, epochs=1, verbose=0)

# Main loop
def train_dqn(sumoCmd):
    model = build_model()
    target_model = build_model()
    target_model.set_weights(model.get_weights())
    epsilon = EPSILON

    for episode in range(EPISODES):
        print(f"Starting episode {episode + 1}/{EPISODES}")
        traci.start(sumoCmd)
        state = get_state()  # Custom function to extract the state from all intersections
        state = np.reshape(state, [1, STATE_SIZE])

        last_action_time = -MIN_GREEN_DURATION  # Initialize last action time

        for step in range(10):  # Define your simulation steps
            if (step - last_action_time) >= MIN_GREEN_DURATION:  # Ensure minimum green duration
                action = act(state, epsilon, model)
                set_phases(action)
                last_action_time = step

            traci.simulationStep()
            next_state = get_state()  # Get the next state
            next_state = np.reshape(next_state, [1, STATE_SIZE])

            reward = calculate_reward()  # Custom function to calculate reward for all intersections
            done = False  # Define your termination condition

            memory.append((state, action, reward, next_state, done))
            state = next_state

            if done:
                break

            replay(model, target_model)

        target_model.set_weights(model.get_weights())
        if epsilon > EPSILON_MIN:
            epsilon *= EPSILON_DECAY
        
        # Save the model after every episode
        model.save(SAVE_MODEL)
        print(f"Model saved after episode {episode + 1}")
        
        if traci.simulation.getMinExpectedNumber() <= 0:  # Stopping condition
            break
        traci.close()
        print(f"Episode {episode + 1}/{EPISODES} finished.\n")

# Example functions for state extraction and reward calculation
def get_state():
    state = []
    for tl_id in traffic_light_ids:
        current_phase = traci.trafficlight.getPhase(tl_id)
        state.append(current_phase)
        
        lane_ids = traci.trafficlight.getControlledLanes(tl_id)
        for lane_id in lane_ids[:5]:  # Adjust for 5 lanes
            num_vehicles = traci.lane.getLastStepVehicleNumber(lane_id)
            state.append(num_vehicles)
    
    return np.array(state)  # Convert the list to a NumPy array

def set_phases(action):
    # Decode the action into phases for all intersections
    for i, tl_id in enumerate(traffic_light_ids):
        phase = (action // (4 ** i)) % 4  # Assuming 4 phases per light
        current_phase = traci.trafficlight.getPhase(tl_id)
        if current_phase != phase:
            # Introduce yellow light before changing phases
            traci.trafficlight.setPhase(tl_id, (current_phase + 1) % 4)
            traci.trafficlight.setPhaseDuration(tl_id, 5)  # 5-second yellow light
            traci.trafficlight.setPhase(tl_id, phase)

def calculate_reward():
    # Define the reward function across all intersections
    reward = 0
    for tl_id in traffic_light_ids:
        for lane_id in traci.trafficlight.getControlledLanes(tl_id):
            waiting_time = traci.lane.getWaitingTime(lane_id)
            halted_vehicles = traci.lane.getLastStepHaltingNumber(lane_id)  # Get the number of vehicles that are stopped
            reward -= waiting_time + (5 * halted_vehicles)  # Penalize both waiting time and halts
    return reward

if __name__ == "__main__":
    sumoCmd = ["sumo-gui", "-c", "t2.sumocfg"]
    train_dqn(sumoCmd)
